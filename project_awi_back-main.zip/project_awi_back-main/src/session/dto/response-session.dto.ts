// session.dto.ts
export class SessionDto {
  idSession: number;
  dateDebut: Date;
  dateFin: Date;
  description: string;
  descriptionPeriode: string;
}