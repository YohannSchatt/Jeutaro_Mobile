export enum Role {
    Admin = 'ADMIN',
    Gestionnaire = 'GESTIONNAIRE',
    User = 'USER'
  }