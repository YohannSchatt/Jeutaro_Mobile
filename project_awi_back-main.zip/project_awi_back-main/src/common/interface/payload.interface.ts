export interface Payload {
    idUtilisateur: number;
    role: string;
}