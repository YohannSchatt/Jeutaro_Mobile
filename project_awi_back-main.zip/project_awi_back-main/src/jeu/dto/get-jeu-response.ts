export class GetJeuResponseDto {

  idJeu: number;


  nom: string;


  editeur: string;

  description: string;


  image: string;
}