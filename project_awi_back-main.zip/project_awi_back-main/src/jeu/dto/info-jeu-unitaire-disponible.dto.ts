export class InfoJeuUnitaireDisponibleDto {
  idJeuUnitaire: number;
  prix: number;
  nom: string;
  editeur: string;
  etat: string;
}