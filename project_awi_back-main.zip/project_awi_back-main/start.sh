#!/bin/sh

npm run start:prod